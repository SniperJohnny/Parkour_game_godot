extends Area2D

@export var speed = 100
@export var current_gravity_constant = 98.7
var currentgravityapplied 
@export var startinggravity = 9.87
var maxgravityapplied = 59987
@export var jumppower = -100
@export var ground_offset: float = 0.05  # adjust to match your character
@export var step_height: float = 8.0      # max pixels the player can auto-climb
@export var player_half_width: float = 4.0  # half the collision shape width
@export var player_half_height: float = 8.0 # half the collision shape height
var space_state
var velocity = Vector2.ZERO
var move_velocity = Vector2.ZERO
var is_on_ground
var lastvalidpos = Vector2.ZERO

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	space_state= get_world_2d().direct_space_state
	currentgravityapplied = startinggravity
	pass # Replace with function body.

func _gravity(delta) -> void:
	
	if(currentgravityapplied <= maxgravityapplied):
		currentgravityapplied += current_gravity_constant * delta
	elif(currentgravityapplied > maxgravityapplied):
		currentgravityapplied = maxgravityapplied
	var query = PhysicsRayQueryParameters2D.create(
			global_position,                          # from
			global_position + Vector2(0, 4),          # to (5 pixels below)
			2147483648                                      # collision_mask (layer 32)
	)
	query.exclude = [self]
	var result = space_state.intersect_ray(query)
	if(result):
		if(currentgravityapplied >= 0):
			currentgravityapplied = 0
			is_on_ground = true
			global_position.y = result.position.y - ground_offset
			print("is_on_ground)")
			print(result)
			return

	velocity.y = currentgravityapplied 
	position += velocity * delta

func _movement(delta):
	
	
	var direction := 0
	if is_on_ground:
		if(Input.is_action_just_pressed("jump")):
			currentgravityapplied = jumppower
			is_on_ground = false
	if(Input.is_action_pressed("move_left")):
		direction -= 1 
	if(Input.is_action_pressed("move_right")):
		direction += 1 
		
	if(direction != 0 and is_on_ground):
		_try_step_up(direction)
	move_velocity.x = direction * speed
		
	position += move_velocity * delta

	lastvalidpos.x = global_position.x
"""
	var query_forward = PhysicsRayQueryParameters2D.create(
			global_position,                          # from
			global_position + Vector2(5, 0),          # to (5 pixels below)
			2147483648                                      # collision_mask (layer 32)
	)
	query_forward.exclude = [self]
	var result_forward = space_state.intersect_ray(query_forward)
	if(result_forward):
		global_position.x = lastvalidpos.x

		print("Hi")
	var query_backwards = PhysicsRayQueryParameters2D.create(
			global_position,                          # from
			global_position + Vector2(-5, 0),          # to (5 pixels below)
			2147483648                                      # collision_mask (layer 32)
	)
	query_forward.exclude = [self]
	var result_backwards = space_state.intersect_ray(query_backwards)
	if(result_backwards):
		global_position.x = lastvalidpos.x

		print("Hi")"""
	
func _try_step_up(direction: int) -> bool:
	# 1. Ray forward at foot level to detect the obstacle
	var foot_y = player_half_height          # distance from origin to feet
	var forward_start = global_position + Vector2(direction * player_half_width, foot_y)
	var forward_end   = forward_start + Vector2(direction * 2, 0)

	var fwd_query = PhysicsRayQueryParameters2D.create(forward_start, forward_end, 2147483648)
	fwd_query.exclude = [self]
	var wall_hit = space_state.intersect_ray(fwd_query)
	if not wall_hit:
		return false   # nothing blocking, no step needed

	# 2. Ray downward from above the obstacle, just past its face
	var probe_x = wall_hit.position.x + direction * 2
	var down_start = Vector2(probe_x, global_position.y - step_height)
	var down_end   = Vector2(probe_x, global_position.y + player_half_height)

	var down_query = PhysicsRayQueryParameters2D.create(down_start, down_end, 2147483648)
	down_query.exclude = [self]
	var floor_hit = space_state.intersect_ray(down_query)
	if not floor_hit:
		return false   # no ground on top -> it's a real wall, don't climb

	# 3. Make sure the step isn't taller than step_height
	var step_up = global_position.y - (floor_hit.position.y - player_half_height)
	if step_up > step_height or step_up <= 0:
		return false

	# 4. Snap the player up onto the step
	global_position.y = floor_hit.position.y - player_half_height
	return true
	
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	_gravity(delta)
	_movement(delta)
	
	
	
	pass
